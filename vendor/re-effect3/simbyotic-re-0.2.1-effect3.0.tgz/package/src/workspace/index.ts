export {
  scanDecks,
  DeckEntrySchema,
  ScanDecksResultSchema,
  ScanDecksErrorSchema,
  WorkspaceRootNotFound,
  WorkspaceRootNotDirectory,
  WorkspaceRootUnreadable,
  mapScanDecksErrorToError,
  toScanDecksErrorMessage,
  type DeckEntry,
  type ScanDecksOptions,
  type ScanDecksResult,
  type ScanDecksError,
} from "./scanDecks.js";

export {
  ResolveDeckImagePathReasonSchema,
  InvalidDeckImagePath,
  ResolvedDeckImagePathSchema,
  isPathWithinRoot,
  resolveDeckImagePath,
  type ResolveDeckImagePathReason,
  type ResolvedDeckImagePath,
} from "./imagePaths.js";

export {
  WORKSPACE_INTERNAL_DIRECTORY_NAME,
  WORKSPACE_IMAGE_ASSETS_DIRECTORY_NAME,
  WORKSPACE_IMAGE_ASSETS_RELATIVE_PATH,
  InvalidWorkspaceImageAssetReasonSchema,
  InvalidWorkspaceImageAsset,
  ImportDeckImageAssetOperationSchema,
  ImportDeckImageAssetOperationError,
  ImportedDeckImageAssetSchema,
  getWorkspaceImageAssetsDirectory,
  importDeckImageAsset,
  importDeckImageAssetFromBytes,
  type InvalidWorkspaceImageAssetReason,
  type ImportDeckImageAssetOperation,
  type ImportedDeckImageAsset,
} from "./imageAssets.js";

export {
  snapshotWorkspace,
  DeckStateCountsSchema,
  DeckSnapshotOkSchema,
  DeckSnapshotReadErrorSchema,
  DeckSnapshotParseErrorSchema,
  DeckSnapshotSchema,
  SnapshotWorkspaceResultSchema,
  SnapshotWorkspaceErrorSchema,
  type DeckStateCounts,
  type DeckSnapshot,
  type SnapshotWorkspaceOptions,
  type SnapshotWorkspaceResult,
  type SnapshotWorkspaceError,
} from "./snapshotWorkspace.js";

export {
  buildDeckTree,
  flattenDeckTree,
  type DeckTreeLeaf,
  type DeckTreeGroup,
  type DeckTreeNode,
  type FlatDeckRow,
} from "./deckTree.js";

export {
  DeckManager,
  DeckManagerLive,
  DeckNotFound,
  DeckReadError,
  DeckParseError,
  DeckWriteError,
  CardNotFound,
  ItemValidationError,
  InvalidDeckPathReasonSchema,
  InvalidDeckPath,
  DeckAlreadyExists,
  DeckFileNotFound,
  DeckFileOperationError,
  type ReadError,
  type WriteError,
  type DeckLifecycleError,
  type RemovedDeckItem,
} from "./DeckManager.js";

export {
  extractCardLocations,
  findDuplicates,
  findWorkspaceDuplicates,
  type CardLocation,
  type DuplicateMap,
  type WorkspaceDuplicateResult,
} from "./duplicateCards.js";

export {
  ReviewQueueBuilder,
  ReviewQueueBuilderLive,
  ReviewQueueService,
  ReviewQueueServiceLive,
  ReviewQueueLive,
  DEFAULT_REVIEW_QUEUE_OPTIONS,
  QueueOrderSpec,
  QueueOrderingStrategy,
  QueueOrderingStrategyFromSpec,
  NewFirstByDueDateSpec,
  DueFirstByDueDateSpec,
  NewFirstShuffledSpec,
  NewFirstFileOrderSpec,
  NewFirstOrderingStrategy,
  DueFirstOrderingStrategy,
  ShuffledOrderingStrategy,
  preserveOrder,
  sortBy,
  shuffle,
  chain,
  byDueDate,
  byFilePosition,
  collectDeckPathsFromSelection,
  type QueueItem,
  type ReviewQueue,
  type ReviewQueueOptions,
  type ReviewQueueOrder,
  type ReviewQueueSelection,
  type WithinGroupOrder,
} from "./reviewQueue.js";

export {
  prepareBuiltinReviewQueue,
  gradeBuiltinCard,
  type BuiltinReviewGradeError,
  type BuiltinReviewGradeResult,
  type ReviewCardReference,
  type PreparedReviewCard,
  type PreparedReviewQueue,
  type ReviewPreparationIssue,
} from "./builtin-review.js";

export { toReadErrorMessage, toWriteErrorMessage } from "./deck-errors.js";
